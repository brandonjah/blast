$(function(){
	$("#launch_tweet_modal_button").click(function(){
		$('#send-tweet-modal').modal("show");
		return false;
	});
});
