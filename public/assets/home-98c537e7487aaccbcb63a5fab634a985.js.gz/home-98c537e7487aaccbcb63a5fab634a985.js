$(function(){
	$(".example a").click(function(){
		$(this).hide();
		$("#example-content").toggle();
		return false;
	});
	$("#cta a").click(function(){
		$("#signup-modal").modal("show");
		return false;
	});
	$("#mc-embedded-subscribe").click(function(){
		$("#signup-modal").modal("hide");
	})
});
